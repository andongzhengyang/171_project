OffYards = function(_parentElement, _data){
    this.parentElement = _parentElement;
    this.data = _data;

    this.loadData();
}

OffYards.prototype.loadData = function() {
    var vis = this;

    vis.data.forEach(function (d) {
        d.Wins = + d.Wins;
        d.YardsAllowed = + d.YardsAllowed;
    });
    vis.initVis();
};

OffYards.prototype.initVis = function() {
    var vis = this
    vis.margin = {top: 80, right: 150, bottom: 80, left: 30};
    vis.width = 960 - vis.margin.left - vis.margin.right;
    vis.height = 400 - vis.margin.top - vis.margin.bottom;

    vis.svg = d3.select("#" + vis.parentElement).append("svg")
        .attr("width", vis.width + vis.margin.left + vis.margin.right)
        .attr("height", vis.height + vis.margin.top + vis.margin.bottom)
        .append("g")
    g = vis.svg.append("g").attr("transform", "translate(" + vis.margin.left + "," + vis.margin.top + ")");




    x = d3.scaleLinear()
        .domain([d3.max(vis.data, function(d, i) { return d.YardsAllowed  - 30; }), d3.min(vis.data, function(d, i) { return d.YardsAllowed  + 400; })])
        .range([vis.width, 0]);

    y = d3.scaleLinear()
        .domain([d3.min(vis.data, function(d, i) { return d.Wins - 3; }), d3.max(vis.data, function(d, i) { return d.Wins + 3; })])
        .range([vis.height, 0]);

    y2 = d3.scaleLinear()
        .domain([d3.min(vis.data, function(d, i) { return d.Wins - 3; }), d3.max(vis.data, function(d, i) { return d.Wins + 3; })])
        .range([4, 30]);


    linearColor = d3.scaleLinear().domain([1,vis.data.length])
        .interpolate(d3.interpolateHcl)
        .range([d3.rgb("#7b6888"), d3.rgb('#d0743c')]);



     yAxis = d3.axisLeft();
     xAxis = d3.axisBottom();
    xAxis.scale(x);
    yAxis.scale(y);

    vis.svg.append("g").attr("class", "axis").attr("transform", "translate(40," + (vis.height - 10) + ")").call(xAxis)
    vis.svg.append("g").attr("class", "axis").attr("transform", "translate(40," + -10 + ")").call(yAxis)



    vis.svg.append("text")
        .attr("transform", "translate(" + (vis.width / 2) + " ," + (vis.height + vis.margin.bottom - 50) + ")")
        .style("text-anchor", "middle")
        .text("Offensive Yards");
    //yAxis label
    vis.svg.append("text")
        .attr("transform", "rotate(-90)")
        .attr("y", 0)
        .attr("x", 0 - (vis.height / 2))
        .attr("dy", "1em")
        .style("text-anchor", "middle")
        .text("Wins");


    // Add tooltip
    tip = d3.tip()
        .attr('class', 'd3-tip')
        .offset([-40, -70])
        .html(function(d, i) {
            return "<span id='tipTextOff' style='color:red'></span>";
        })

    vis.svg.call(tip);


    vis.wrangleData();
};

OffYards.prototype.wrangleData = function() {
    var vis = this;


    vis.updateVis()


}

OffYards.prototype.updateVis = function(){
    var vis = this;

    vis.svg.selectAll("circle")
        .data(vis.data)
        .enter()
        .append("circle")
        .style("opacity", 0.8)
        .attr("cx", function(d, i){
            return x(d.YardsAllowed)
        })
        .attr("cy", function(d, i) {
            return y(d.Wins)
        }).attr("r", function(d, i) {
        return y2(d.Wins)
    })
        .attr("fill", function(d, i) {
            if (d.Conference == "AFC"){
                return linearColor(1)
            }
            if (d.Conference == "NFC"){
                return linearColor(15)
            }
        }).attr("stroke-width", 1)
        .attr("stroke", "black")
        .on("mouseover", function(d, i) {
            console.log(this.cx)
            d3.select(this)
                .style("opacity", 1)

            tip.show()
            $("#tipTextOff").html("Team: " + d.City+"<br/>W-L%: "+d.WL + "%");

        })
        .on("mouseout", function(d) {
            tip.hide()
            d3.select(this)
                .style("opacity", 0.8)
        })



    // Add Text Labels
    vis.svg.selectAll("text")
        .data(vis.data)
        .enter()
        .append("text")
        .attr("x", function(d) {
            return x(d.YardsAllowed);
        })
        .attr("y", function(d) {
            return y(d.Wins);
        })
        .text(function(d) {
            console.log(d)
            return d.City
        })
        .attr("font_family", "sans-serif")
        .attr("font-size", "11px")
        .attr("fill", "darkgreen");

}